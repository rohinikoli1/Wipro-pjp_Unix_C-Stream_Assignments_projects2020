
#include <stdio.h>


int main()

{
    
	int n[10],num,i,sele,flag=-1;
    
	printf("Enter size of the array: ");
    
	scanf("%d",&num);
    
	printf("Enter the array elements: ");
    
	for(i=0;i<num;i++)
    
	{
        
		scanf("%d",&n[i]);
    
	}
    
	printf("Enter the element that to be search: ");
    	
	scanf("%d",&sele);
    
	for(i=0;i<num;i++)
    
	{
        
		if(sele==n[i])flag=i;
    
	}
    
	if(flag==-1)printf("!!! Element not found !!!");
    
	else printf(" Element is found and its index is %d",flag);
    
	return 0;

}
