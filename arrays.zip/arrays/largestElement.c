#include <stdio.h>
int main() {
    int i, n, arr[100];
    printf("Enter the size of the array: ");
    scanf("%d", &n);
    printf("Enter %d numbers \n",n);
    for (i = 0; i < n; ++i) {
        scanf("%d", &arr[i]);
    }

    // storing the largest number to arr[0]
    for (i = 1; i < n; ++i) {
        if (arr[0] < arr[i])
            arr[0] = arr[i];
    }

    printf("Largest element is %d", arr[0]);

    return 0;
}