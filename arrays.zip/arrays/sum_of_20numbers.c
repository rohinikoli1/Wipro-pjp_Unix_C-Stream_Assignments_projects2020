 #include <stdio.h>
 void main ()
	 {
        		int num,i=0,sum=0,count=0;
		printf("Enter the 20 elements in the array: \n");
		for(i=0;i<20;i++)
		{
			scanf("%d",&num);
			if(num%2==0)
			{
				sum=sum+num;
				count=count+1;
			}
		}
		printf(" sum of all even numbers is %d \n",sum);
		printf(" count of even numbers is %d \n",count);
	}