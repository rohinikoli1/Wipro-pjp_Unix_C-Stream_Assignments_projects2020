
#include <stdio.h>


int main()

{
    
	int n[10],num,i;
	
	float avg=0,sum=0;
    
	printf("Enter size of the array: ");
    
	scanf("%d",&num);
    
	printf("Enter %d numbers : ",num);
    
	for(i=0;i<num;i++)
    
	{
        
		scanf("%d",&n[i]);
  
		sum=sum+n[i];  
	}
	avg=sum/num;printf("Sum of all the elements in the array is  %f\n",sum);
		printf("Avaerege of all input numbers  %f\n",avg);
	return 0;

}
