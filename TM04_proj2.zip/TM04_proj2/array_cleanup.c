

#include <stdio.h>


#include <conio.h>
 

int remove_duplicate(int *a,int n)

{ 
    
	int i,c=0,j,k=0;
   
    
	for(i=0; i<n; i++)
    
	{
        
		if(a[i]!=-1)
		
		{
		    
			for(j=i+1; j<n; j++)
     
            
			{
        	   
				if(a[i]==a[j])
        	    
				{
			       
					c++;

					a[j]=-1;
		       
				}
	       
			}
 		
		}
        
		if(a[i]!=-1)
        
		{
        	 
			a[k++]=a[i];
 
		
		} 
   
   
          
    
	}
    
	return n-c;
     
 
}
 
 
print(int *a,int n)
 
{ 
    
	int i,j,k;
    
    
    for(i=0; i<n; i++)
    {
        if(a[i]==0 || a[i]>10 )
        {
            
        }
        else
        {
            printf("%d  ",a[i]);
        }
	}
 	
 }
int main()
{
    int a[10000],b[10000],i,n;
   
    printf("Enter size of the array : ");
    scanf("%d", &n);
 
    printf("Enter elements in array : ");
    for(i=0; i<n; i++)
    {
        scanf("%d",&a[i]);
    }
    
    n=remove_duplicate(a,n);
    
	printf("elements after deleting duplicates in array :\n");
 
	print(a,n);   
    
	return 0;
}
