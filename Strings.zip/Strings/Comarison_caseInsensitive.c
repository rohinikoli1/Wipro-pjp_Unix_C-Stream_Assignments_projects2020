#include <stdio.h>
#include <string.h>
int stringCmpi(char *s1,char *s2);
int main()
{
    char str1[100],str2[100];
 
	printf("Enter  string 1 : ");
    	scanf("%[^\n]s",str1);//read string with spaces

    	getchar(); //to read enter after first string
 
    	printf("Enter  string 2 : ");
    	scanf("%[^\n]s",str2);//read string with spaces
 
   
 
    if(!stringCmpi(str1,str2))
        printf("\n stringCmpi :String are same.");
    else
        printf("\n stringCmpi :String are not same.");
 
 
    printf("\n");
    return 0;
}
 

/******** function definition *******/
int stringCmpi (char *s1,char *s2)
{
    int i=0,diff=0;
    for(i=0; s1[i]!='\0'; i++)
    {
        if( toupper(s1[i])!=toupper(s2[i]) )
            return 1;           
    }
    return 0;
}