#include <stdio.h>
#include <string.h>
int mystrlen(char *s1);
int main()
{
    char str1[100];
    int n;
	printf("Enter  string  : ");
    	scanf("%[^\n]s",str1);//read string with spaces

    	getchar(); //to read enter after first string
 
    	n=mystrlen(str1);
        printf(" The length of String is %d",n);
 
 
    printf("\n");
    return 0;
}
 

/******** function definition *******/
int mystrlen (char *s1)
{
    int i=0,diff=0;
    for(i=0; s1[i]!='\0'; i++)
    {
        diff=diff+1;
    }
    return diff;
}