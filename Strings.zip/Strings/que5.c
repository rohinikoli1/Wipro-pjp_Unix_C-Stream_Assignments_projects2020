#include<stdio.h>
#include<conio.h>
void vowelstoz(char *str)
{
    int i;
    char ch='z';
    for(i=0; str[i]!='\0'; i++)
    {
        if(str[i]=='a' || str[i]=='e' || str[i]=='i' || str[i]=='o'
           || str[i]=='u' || str[i]=='A' || str[i]=='E' || str[i]=='I'
           || str[i]=='O' || str[i]=='U')
        {
            str[i] = ch;
        }
    }
    printf("\nNew String (after replacing vowel with %c) = %s", ch, str);
}
int main()
{
    char str[50];
    printf("Enter any string: ");
    gets(str);
    vowelstoz(str);
    return 0;
}