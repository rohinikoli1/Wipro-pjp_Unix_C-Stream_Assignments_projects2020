#include <stdio.h>
#include<string.h>

struct empdata
{
	
char ename[20];
	
int eno;
	
long int empphno;

};
int main()
{
    struct empdata *ePtr, e1;
    ePtr = &e1;   

    printf("Enter Name: ");
    scanf("%s", &ePtr->ename);

    printf("Enter employee number ");
    scanf("%d", &ePtr->eno);

    printf("Enter employee  phone number ");
    scanf("%lu", &ePtr->empphno);

   printf("Employee details are :- \n");
    
printf("Name :- %s\n",ePtr->ename);
    
printf("Employee Number :- %d\n",ePtr->eno);
  
 printf("Employee phone number :- %lu\n",ePtr->empphno);
    return 0;
}