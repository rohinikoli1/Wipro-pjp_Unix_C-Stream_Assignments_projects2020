#include <stdio.h>

#include<string.h>


struct Cricketerdatabatsman
{
	
char name[100];
	
int age;
	
int highestscore;
	int leastscore;
	int noofzeros;
};


void cricketerdata_print(struct s)
{
	printf("cricketer details are \n \n Cricketer name:- \t %s \n HighestScore :- \t %d \n LeastScore :- \t %d \n No of Zeros:- \t %d \n ",s.name,s.age,s.highestscore,s.leastscore,s.noofzeros);


}
int main()

{
    
	struct Cricketerdatabatsman c[5];
  
	int i;
	for(i=0;i<5;i++)  
	{
		printf("Enter %d Cricketer detail \n",i+1);
    
		printf("Cricketer Name :-\t");
    
		scanf("%s",&c[i].name);
    
		printf("Age :-\t");
    
		scanf("%d",&c[i].age);
    
		printf("HighScore :-\t");
    
		scanf("%d",&c[i].highestscore);
    
		printf("LeastScore :-\t");
    
		scanf("%d",&c[i].leastscore);
		printf("No of Zeros :-\t");
    
		scanf("%d",&c[i].noofzeros);	
		printf("\n \n");

    	}
	
for(i=0;i<5;i++)
	{
  		cricketerdata_print(c[i]);
	}     
	return 0;

}