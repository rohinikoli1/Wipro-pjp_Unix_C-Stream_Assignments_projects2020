#include <stdio.h>

#include<string.h>


struct empdata
{
	
char ename[100];
	
int eno;
	
long int empphno;

};


int main()

{
    
	struct empdata e[20];
  
	int i;
	for(i=0;i<20;i++)  
	{
		printf("Enter %d Employee detail \n",i+1);
    
		printf("Emp Name :-\t");
    
		scanf("%s",&e[i].ename);
    
		printf("Emp No :-\t");
    
		scanf("%d",&e[i].eno);
    
		printf("Emp phone number :-\t");
    
		scanf("%lu",&e[i].empphno);
    
		printf("\n \n");

    	}
	
for(i=0;i<20;i++)
	{
		printf(" %d Employee details are \n \n Employee name:- \t %s \n Employee number:- \t %d \n Employee phone number :- \t %lu ",i+1,e[i].ename,e[i].eno,e[i].empphno);

		printf("\n \n");
    
	}     
	return 0;

}