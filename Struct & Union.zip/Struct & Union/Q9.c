#include <stdio.h>

#include<string.h>


struct data
{
	int num1;
	int num2;
	int num3;
	
int  avg;

};


struct data *calaverage( struct data *d)
{
	d->avg=(d->num1+d->num2+d->num3)/3;
	return d;
}
int main()

{
    	struct data d;
	struct data *d1=&d,*d2;
      
	

printf(" Enter 3 numbers for avaerage calculate :- \n");
	scanf(" %d %d %d ",&d.num1,&d.num2,&d.num3);
	d2=calaverage(d1);
	printf("The average = %d", d2->avg); 	
   	return 0;

}