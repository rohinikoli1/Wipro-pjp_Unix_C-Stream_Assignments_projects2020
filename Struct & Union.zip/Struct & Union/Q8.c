#include <stdio.h>
#include <stdlib.h>
struct empdata
{
	
char ename[20];
	
int eno;
	
long int empphno;

};


int main()
{
 	struct empdata *e1,*e2,*e3;
   	int i;
   	e1 = (struct empdata*) malloc(sizeof(struct empdata));
	e2 = (struct empdata*) malloc(sizeof(struct empdata));
	e3 = (struct empdata*) malloc(sizeof(struct empdata));
	printf("\n Enter first Employee details : ");
	scanf("%s %d %lu", &e1->ename, &e1->eno,&e1->empphno);
	printf("\n Enter second Employee details : ");
	scanf("%s %d %lu", &e2->ename, &e2->eno,&e3->empphno);
	printf("\n Enter third Employee details : ");
	scanf("%s %d %lu", &e3->ename, &e3->eno,&e3->empphno);
   	printf("\n Displaying Information:\n");
	printf("\n Name: %s\t Employee number: %d\t Phone number: %lu ", e1->ename, e1->eno,e1->empphno);
	printf("\n Name: %s\t Employee number: %d\t Phone number: %lu ", e2->ename, e2->eno,e2->empphno);
	printf("\n Name: %s\t Employee number: %d\t Phone number:%lu ", e3->ename, e3->eno,e3->empphno);

   return 0;
}