#include <stdio.h>

#include<string.h>


struct empdata
{
	
char ename[20];
	
int eno;
	
long int empphno;

};


int main()

{
    
	struct empdata e1,e2,e3;
    
	printf("Enter first Employee detail \n");
    
	printf("Emp Name :-\t");
    
	scanf("%s",&e1.ename);
    
	printf("Emp No :-\t");
    
	scanf("%d",&e1.eno);
    
	printf("Emp phone number :-\t");
    
	scanf("%lu",&e1.empphno);
    
	printf("\n \n");
    
	printf("Enter second Employee detail \n");
    
	printf("Emp Name :-\t");
    
	scanf("%s",&e2.ename);
    
	printf("Emp No :-\t");
    
	scanf("%d",&e2.eno);
    
	printf("Emp phone number :-\t");
    
	scanf("%lu",&e2.empphno);
    
	printf("\n \n");
    
	printf("Enter third Employee detail \n");
    
	printf("Emp Name :-\t");
    
	scanf("%s",&e3.ename);
    
	printf("Emp No :-\t");
    
	scanf("%d",&e3.eno);
    
	printf("Emp phone number :-\t");
    
	scanf("%lu",&e3.empphno);
   
	printf("\n \n");
    
	printf(" First Employee details are \n \n Employee name:- \t %s \n Employee number:- \t %d \n Employee phone number :- \t %lu ",e1.ename,e1.eno,e1.empphno);

	printf("\n \n");
    
	printf(" Second Employee details are \n \n Employee name:- \t %s \n Employee number:- \t %d \n Employee phone number :- \t %lu ",e2.ename,e2.eno,e2.empphno);
    	printf("\n \n");
    
	printf(" Third Employee details are \n \n Employee name:- \t %s \n Employee number:- \t %d \n Employee phone number :- \t %lu ",e3.ename,e3.eno,e3.empphno);

    	return 0;

}