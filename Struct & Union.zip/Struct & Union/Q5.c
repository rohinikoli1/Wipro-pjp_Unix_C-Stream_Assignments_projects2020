#include <stdio.h>

#include<string.h>


struct data
{
	int num1;
	int num2;
	int num3;
	
int  avg;

};


struct calaverage( struct data d)
{
	d.avg=(num1+num2+num3)/3;
	return d;
}
int main()

{
    
	struct data d1;
    
	

printf(" Enter 3 numbers for avaerage calculate :- \n");
	scanf(" %d %d %d ",&num1,&num2,&num3);
	d1=calavaerage(d1);
	printf("The average = %d", d1.avg); 	
   	return 0;

}