#include <stdio.h>

#include<string.h>


struct Cricketerdatabatsman
{
	
char name[100];
	
int age;
	
int highestscore;
	int leastscore;
	int noofzeros;
};


void cricketerdata_print(struct s[])
{
	int i;
	for(i=0;i<5;i++)
	{

		printf("cricketer details are \n \n Cricketer name:- \t %s \n HighestScore :- \t %d \n LeastScore :- \t %d \n No of Zeros:- \t %d \n ",s[i].name,s[i].age,s.highestscore,s[i].leastscore,s[i].noofzeros);
	}


}
int main()

{
    
	struct Cricketerdatabatsman c[5];
  
	int i;
	for(i=0;i<5;i++)  
	{
		printf("Enter %d Cricketer detail \n",i+1);
    
		printf("Cricketer Name :-\t");
    
		scanf("%s",&c[i].name);
    
		printf("Age :-\t");
    
		scanf("%d",&c[i].age);
    
		printf("HighScore :-\t");
    
		scanf("%d",&c[i].highestscore);
    
		printf("LeastScore :-\t");
    
		scanf("%d",&c[i].leastscore);
		printf("No of Zeros :-\t");
    
		scanf("%d",&c[i].noofzeros);	
		printf("\n \n");

    	}
	
cricketerdata_print(c);
	return 0;

}