#include <stdio.h>

#include<string.h>


struct studentdata
{
	
char studentname[100];
	
int SRollno;
	int mark1;
	int mark2
	int mark3;
	
int  avg;

};


int main()

{
    
	struct studentdata e1,e2,e3;
    
	printf("Enter first student detail \n");
    
	printf("Student Name :-\t");
    
	scanf("%s",&e1.studentname);
    
	printf("Student roll No :-\t");
    
	scanf("%d",&e1.SRollno);
    
	printf("Enter marks of 3 subjects :-\t");
    
	scanf("%d",&e1.mark1);
	scanf("%d",&e1.mark2);

    	scanf("%d",&e1.mark3);
	e1.avg=(e1.mark1+e1.mark2+e1.mark3);
	printf("\n \n");
    
	printf("Enter second student detail \n");
    
	printf("Student Name :-\t");
    
	scanf("%s",&e2.studentname);
    
	printf("Student roll No :-\t");
    
	scanf("%d",&e2.SRollno);
    
	printf("Enter marks of 3 subjects :-\t");
    
	scanf("%d",&e2.mark1);
	scanf("%d",&e2.mark2);

    	scanf("%d",&e2.mark3);   
	printf("\n \n");

	printf("Enter third student detail \n");
    
	printf("Student Name :-\t");
    
	scanf("%s",&e3.studentname);
    
	printf("Student roll No :-\t");
    
	scanf("%d",&e3.SRollno);
    
	printf("Enter marks of 3 subjects :-\t");
    
	scanf("%d",&e3.mark1);
	scanf("%d",&e3.mark2);

    	scanf("%d",&e3.mark3);
	e2.avg=(e2.mark1+e2.mark2+e2.mark3);
	e3.avg=(e3.mark1+e3.mark2+e3.mark3);
	printf("\n \n");

 

 	if(e1.avg>e2.avg && e1.avg>e3.avg)
	{
		print("Student with highest average marks is %s and its marks is %d ",e1.studentname,e1.avg);
		if(e2.avg>e3.avg)
		{
			print("Student with  average marks is %s and its marks is %d ",e2.studentname,e2.avg);	
			print("Student with least average marks is %s and its marks is %d ",e3.studentname,e3.avg);
		}
		else
		{
			print("Student with  average marks is %s and its marks is %d ",e3.studentname,e3.avg);
			print("Student with least average marks is %s and its marks is %d ",e2.studentname,e2.avg);
		}

	}
	if(e2.avg>e1.avg && e2.avg>e3.avg)
	{
		print("Student with highest average marks is %s and its marks is %d ",e2.studentname,e2.avg);
		if(e1.avg>e3.avg)
		{
			print("Student with  average marks is %s and its marks is %d ",e1.studentname,e1.avg);
			print("Student with least average marks is %s and its marks is %d ",e3.studentname,e3.avg);	
		}
		else
		{
			print("Student with  average marks is %s and its marks is %d ",e3.studentname,e3.avg);
			print("Student with least average marks is %s and its marks is %d ",e1.studentname,e1.avg);
		}

	}
	
	if(e3.avg>e1.avg && e3.avg>e2.avg)
	{
		print("Student with highest average marks is %s and its marks is %d ",e3.studentname,e3.avg);
		if(e1.avg>e2.avg)
		{
			print("Student with  average marks is %s and its marks is %d ",e1.studentname,e1.avg);
			print("Student with least average marks is %s and its marks is %d ",e2.studentname,e2.avg);	
		}
		else
		{
			print("Student with  average marks is %s and its marks is %d ",e2.studentname,e2.avg);
			print("Student with least average marks is %s and its marks is %d ",e1.studentname,e1.avg);
		}

	}
   	return 0;

}