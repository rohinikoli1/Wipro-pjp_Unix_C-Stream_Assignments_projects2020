
#include <stdio.h>
#define MAX_SIZE 100 // Maximum array size
void printArray(int arr[], int size);
void printSizeOf(int intArray[])
{
    printf("sizeof of array: %d\n",sizeof(intArray));
}
void sort(int * arr, int size, int (* compare)(int *, int *))
{
    // Pointer to last array element
    int * arrEnd  = (arr + size - 1);

    // Pointer to current array element
    int * curElem = arr;
    int * elemToSort;


    // Iterate over each array element
    while(curElem <= arrEnd)
    {
        elemToSort = curElem;


        // Compare each successive elements with current element
        // for proper order.
        while(elemToSort <= arrEnd)
        {
            /*
             * Compare if elements are arranged in order 
             * or not. If elements are not arranged in order
             * then swap them.
             */
            if(compare(curElem, elemToSort) > 0)
            {
                *curElem    ^= *elemToSort;
                *elemToSort ^= *curElem;
                *curElem    ^= *elemToSort;
            }

            elemToSort++;
        }

        // Move current element to next element in array.
        curElem++;
    }
}
int sortAscending(int * num1, int * num2)
{
    return (*num1) - (*num2);
}

int main()
{
    int source_arr[MAX_SIZE], dest_arr[MAX_SIZE];
    int size=10, i;

    int *source_ptr = source_arr;   // Pointer to source_arr
    int *dest_ptr   = dest_arr;     // Pointer to dest_arr

    int *end_ptr;


    /*
     * Input size and elements in source array
     */
    //printf("Enter size of array: ");
    //scanf("%d", &size);
    printf("Enter 10 students marks: ");
    for (i = 0; i < size; i++)
    {
        scanf("%d", (source_ptr + i));
    }


    // Pointer to last element of source_arr
    end_ptr = &source_arr[size - 1];



    /*
     * Run loop till source_ptr exists in source_arr
     * memory range.
     */
    while(source_ptr <= end_ptr)
    {
        *dest_ptr = *source_ptr;

        // Increment source_ptr and dest_ptr
        source_ptr++;
        dest_ptr++;
    }
   printSizeOf(source_arr);
   sort(dest_arr, size, sortAscending);
    printf("Marks after sorting: \n");
    printArray(dest_arr, size);


    return 0;
}


/**
 * Function to print array elements.
 * 
 * @arr     Integer array to print.
 * @size    Size of array.
 */
void printArray(int *arr, int size)
{
    int i;

    for (i = 0; i < size; i++)
    {
        printf("%d, ", *(arr + i));
    }
}
