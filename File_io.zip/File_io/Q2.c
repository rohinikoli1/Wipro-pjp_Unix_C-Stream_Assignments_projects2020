#include <stdio.h>

void main(int argc,char *argv[])

{

char ch;

FILE *  fptr1=fopen(argv[1],�r�);//open file in read mode

FILE *  fptr2=fopen(argv[2],�w�);//open file in write mode

 

clrscr();

if(!fptr1)

 printf(�\nCan not open file for reading��);

else

{

    while((ch=getc(fptr1))!=EOF)

      putc(ch,fptr2);

  fclose(fptr1);

  fclose(fptr2);

printf(�\n 1 file is copied��);

 }

printf(�\n\nPress any key ��);

getch();

}