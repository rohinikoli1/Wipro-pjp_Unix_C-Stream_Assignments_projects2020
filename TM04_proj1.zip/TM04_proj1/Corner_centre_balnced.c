#include <stdio.h>

int main() 
{
    
	int centre_sum=0,arr[9],i,corner_sum=0;
    
	printf("Enter the elememts of the array : \n");
    
	for(i=0;i<9;i++)scanf("%d",&arr[i]);
    
	corner_sum=arr[0]+arr[2]+arr[6]+arr[8];
    
	centre_sum=arr[1]+arr[3]+arr[5]+arr[7];
    
	if(corner_sum>centre_sum)printf("1");
    
	else if(centre_sum>corner_sum)printf("2");
    
	else printf("3");
    
	return 0;

}